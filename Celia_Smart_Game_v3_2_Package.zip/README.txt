Celia Smart Game v3.2 — Release candidate
Official display name: سيليا احمد محمد زكى / Celia Ahmed MZ

Files
- index.html: main app with an optimized copy of Celia's pharaonic-dress portrait embedded as the main portrait.
- celia-pharaonic.jpg: original supplied photo included in package.
- icon-192.png and icon-512.png: app icons derived from the same photo.
- manifest.webmanifest and sw.js: installable PWA metadata and offline cache.

Run locally: open index.html in a modern browser. Speech synthesis and PWA/offline features depend on browser/device support; service workers require HTTPS or localhost.

Checks completed: JavaScript syntax validation with Node.js; manifest JSON parse; verified portrait embedded in HTML; verified required package files; ZIP integrity check. A full interactive Android/browser test and public deployment have NOT been completed.

Limitations: no deployment to a public host was performed here. Search links to external videos are not pre-approved clips and should be reviewed by an adult. Browser-generated voice is synthetic, not genuine animal recordings. This is an educational demo, not a certified child-safety product.
